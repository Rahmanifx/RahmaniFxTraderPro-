export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-700 text-white">
      <h1 className="text-3xl font-bold">Rahmani FX Trader Pro</h1>
    </div>
  );
}
